"""Backend core utilities."""
